/*
 * Befehlsinterpreter.h
 *
 * Created: 23.03.2019 15:02:11
 *  Author: Uwe
 */ 


#ifndef BEFEHLSINTERPRETER_H_
#define BEFEHLSINTERPRETER_H_

void BefInt (void);

#endif /* BEFEHLSINTERPRETER_H_ */